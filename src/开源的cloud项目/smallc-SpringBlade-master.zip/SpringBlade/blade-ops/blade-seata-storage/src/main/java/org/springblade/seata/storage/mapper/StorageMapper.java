package org.springblade.seata.storage.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.springblade.seata.storage.entity.Storage;

/**
 * StorageMapper
 *
 * @author Chill
 */
public interface StorageMapper extends BaseMapper<Storage> {
}

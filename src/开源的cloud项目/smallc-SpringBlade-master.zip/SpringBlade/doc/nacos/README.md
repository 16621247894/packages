* SpringBlade的注册中心
* 具体文档详见：https://nacos.io/zh-cn/docs/quick-start.html
* docker部署详见：https://github.com/nacos-group/nacos-docker
* SpringBlade配置详见：https://www.kancloud.cn/smallchill/blade/913215